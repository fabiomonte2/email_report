from flask import Flask, render_template, request
from email_extraction import conexao_email, extrair_dados, analisar_emails

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_report', methods=['POST'])
def generate_report():
    username = "fabiomonte898@gmail.com"
    app_password = "mzjx osip yksg ddks"
    imap_url = "imap.gmail.com"
    sender_email = "luizfelipesenai22@gmail.com"

    mail = conexao_email(username, app_password, imap_url)
    email_data = extrair_dados(mail, sender_email)
    mail.logout()

    df = analisar_emails(email_data)
    return render_template('report.html', tables=[df.to_html(classes='data')], titles=df.columns.values)

if __name__ == '__main__':
    app.run(debug=True)