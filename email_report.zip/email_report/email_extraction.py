import imaplib
import email
from email.header import decode_header
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

def conexao_email(username, app_password, imap_url):
    mail = imaplib.IMAP4_SSL(imap_url)
    mail.login(username, app_password)
    mail.select("inbox")
    return mail

def extrair_dados(mail, sender_email):
    status, messages = mail.search(None, f'(FROM "{sender_email}")')
    email_ids = messages[0].split()
    email_data = []

    for email_id in email_ids:
        status, msg_data = mail.fetch(email_id, "(RFC822)")
        for response_part in msg_data:
            if isinstance(response_part, tuple):
                msg = email.message_from_bytes(response_part[1])
                date = email.utils.parsedate_to_datetime(msg["Date"])
                subject = decode_header(msg["Subject"])[0][0]
                if isinstance(subject, bytes):
                    subject = subject.decode()
                if msg.is_multipart():
                    for part in msg.walk():
                        content_type = part.get_content_type()
                        if content_type == "text/plain" and "attachment" not in part.get("Content-Disposition", ""):
                            body = part.get_payload(decode=True).decode()
                            email_data.append((date, body))
                else:
                    body = msg.get_payload(decode=True).decode()
                    email_data.append((date, body))
    return email_data

def analisar_emails(email_data):
    df = pd.DataFrame(email_data, columns=["Date", "Bory"])
    df["Day"] = df["Date"].dt.date
    df["Week"] = df["Date"].dt.isocalendar().week
    df["Year"] = df["Date"].dt.year

    # Salvar gráficos como imagens
    daily_counts = df.groupby("Day").size()
    plt.figure(figsize=(5, 5))
    daily_counts.plot(kind="bar", color="green")
    plt.title("Emails por Dia")
    plt.xlabel("Dia")
    plt.ylabel("Quantidade de Emails")
    plt.savefig('static/uploads/emails_por_dia.png')
    plt.close()

    weekly_counts = df.groupby("Week").size()
    plt.figure(figsize=(5, 5))
    weekly_counts.plot(kind="bar", color="yellow")
    plt.title("Emails por Semana")
    plt.xlabel("Semana")
    plt.ylabel("Quantidade de Emails")
    plt.savefig('static/uploads/emails_por_semana.png')
    plt.close()

    yearly_counts = df.groupby("Year").size()
    plt.figure(figsize=(5, 5))
    yearly_counts.plot(kind="bar", color="purple")
    plt.title("Emails por Ano")
    plt.xlabel("Ano")
    plt.ylabel("Quantidade de Emails")
    plt.savefig('static/uploads/emails_por_ano.png')
    plt.close()

    # Retornar DataFrame para exibição na tabela
    return df
